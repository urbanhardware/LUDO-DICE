# LUDO DICEORA — Starter

## Run
Open `index.html` in a modern browser. It is a starter local pass-and-play prototype.

## Current scope
- Responsive mobile web prototype
- 2–4 local players
- Dice, token movement, capture, safe squares, win check

## Important
This is not yet a production Ludo implementation. The board/token rendering and rules need testing and refinement. Online multiplayer is not connected yet; it needs a realtime backend (for example Firebase) with room creation, join codes, turn validation, and anti-cheat checks.

## Android path
After testing the web game, package it as an Android app with Capacitor. Then add Firebase Authentication/Realtime Database for online rooms, test on real devices, and build a signed APK/AAB.
